# 给负责接入的智能体

1. 阅读 README.md 和 manifest.json，先确认你当前客户端支持的传输与配置格式。
2. 获取用户本机 Creator 连接描述。公开仓库模板里的地址/Token 是占位内容，不能拿来连接；缺失时请用户从插件复制或导出，不能猜测。
3. 运行 scripts/configure.mjs 生成私有配置，只合并当前服务项，不覆盖其他设置。用户已要求安装时可执行该范围内的安装；不要把私密文件提交到 Git。
4. 安装 skills/super-cocos-creator-mcp 到当前客户端实际支持的技能位置；不支持技能时读取正文作为项目说明，不声称已经自动安装。
5. 重新加载后调用 creator_status，核对项目路径，再进行场景编辑。不自动试跑会修改场景的工具。
6. HTTP 是通用接入；只有客户端支持这里的 WebSocket framing 和鉴权时才选择 WS。只支持 stdio 时用 scripts/http-stdio.mjs。
7. 保存配置与实际安装结果，区分“文件已生成”“客户端已加载”“Creator 连接验证成功”。不声称未实测客户端已兼容。
