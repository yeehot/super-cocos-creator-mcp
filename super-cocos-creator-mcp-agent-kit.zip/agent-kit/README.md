# Super Cocos Creator MCP 多智能体接入包

作者：leeming。

把此目录放进 Git，客户或智能体从这里读取安装方法、配置模板与技能。它不包含任何真实连接 Token。需要 Creator 3.8.x 在同一台电脑运行并启用插件；Git 仓库不替代本机服务，不会自动连接云端智能体。

## 给客户：最短安装流程

1. 安装 Creator 插件。Codex / Cursor 可直接用插件内原有的一键安装菜单。
2. 其他智能体：在“查看／复制连接配置”选择“自己的软件：单个连接配置”，复制内容，保存为本机 `connection.local.json`。
3. 把仓库交给智能体，说：“请阅读 agent-kit/README.md，使用我本机的 connection.local.json 配置当前客户端，并安装配套使用说明。”
4. 配置后重新加载客户端，调用 `creator_status` 确认项目路径。

新版插件也提供“导出多智能体接入包”：选择本机目录，导出技能、模板、脚本和当前连接描述。导出的 connection.local.json 含认证信息，仅供本机使用，不能提交到公开仓库。

## 自动生成各客户端的配置

安装 Node.js 20+，无需安装 npm 依赖：

```sh
node agent-kit/scripts/configure.mjs --connection connection.local.json --out .local/creator-clients
```

脚本仅生成文件，不覆盖现有客户端设置。将生成配置中的当前 Creator 服务项合并到客户端已有配置，保留其他服务。

- `codex.config.toml` → 合并至 Codex 的 config.toml。原有插件一键安装仍可用。
- `cursor.mcp.json` → 合并至 Cursor 的 MCP 设置。
- `vscode.mcp.json` → 合并至项目 `.vscode/mcp.json`，使用顶层 servers。
- `claude-code.mcp.json` → 合并至 Claude Code 项目 `.mcp.json`，包含 type:http。
- `claude-desktop.stdio.json` → 本地 Claude Desktop MCP 配置，使用随包提供的 stdio 桥接，必须保留脚本的绝对路径和 Node.js。
- `generic-stdio.json` → 其他支持 command/args/env 的本地 MCP 客户端，按其格式调整。
- `generic-http.json` → 自研软件或其他支持 Streamable HTTP 的客户端，按其格式调整。
- `generic-websocket.json` → 自研 WebSocket 客户端的连接描述，不是所有客户端均可导入的标准配置。

输出文件含本机凭据，目录中自动生成 .gitignore。不要强制添加这些文件，也不要直接覆盖已有的客户端配置文件。移动接入包后，需要重新生成配置以更新 stdio 脚本路径。客户端兼容性受版本影响；这里只保证配置生成、SDK 桥接和插件协议测试，不代表每款客户端均已实机验收。

格式参考：[VS Code MCP](https://code.visualstudio.com/docs/agents/reference/mcp-configuration)、[Claude Code MCP](https://code.claude.com/docs/en/mcp)、[Cursor MCP](https://docs.cursor.com/context/model-context-protocol)。

## 技能和通用使用说明

统一来源是 `skills/super-cocos-creator-mcp/SKILL.md`。支持 Agent Skills 的客户端可安装整个 super-cocos-creator-mcp 文件夹；客户端使用自己的技能目录，不应假设所有软件共享一个目录。

不支持技能的客户端，把该文件正文作为项目指令或系统提示的参考。`AGENTS.md` 说明如何由智能体完成接入，`manifest.json` 提供机器可读的文件清单。技能不会自动建立 MCP 连接，两者都需配置。

## WebSocket 的协议和用途

- 地址：与 HTTP 相同端口，`ws://127.0.0.1:<port>/mcp/ws`。
- 升级请求需要 `Authorization: Bearer <token>`，Token 不放在 URL 中。
- 每个文本帧是一条 MCP JSON-RPC 2.0 消息，先 initialize，再 notifications/initialized，然后 tools/list 或 tools/call。
- 持续连接，支持多个请求按 ID 匹配返回；最多 8 个连接、每连接 32 个未完成请求、入站帧上限 1 MiB。慢客户端会断开，不自动重放写入操作。
- 不提供通用任务进度订阅。现有后台任务仍用 creator_job_status 或资源库 jobs 查询。断线后的任务先查询状态，不要盲目重试。
- 浏览器原生 WebSocket API 不能设置 Authorization header，不能直接使用这个接入方式；桌面应用的后端或 Node.js WebSocket 客户端可以。

自研客户端示例：先在完整源码仓库执行 npm ci，然后设置本机 `CREATOR_MCP_WS_URL`、`CREATOR_MCP_TOKEN`，运行 `node agent-kit/examples/websocket-client.mjs`。独立拿走 agent-kit 时，WebSocket 示例需要安装 ws 和 @modelcontextprotocol/sdk；HTTP/stdio 的生成和桥接脚本不需要第三方依赖。

WebSocket 可以省去逐请求建立 MCP 服务对象，适合持续交互，但 Creator 执行、资源导入和截图通常才是主要耗时。没有基准测试前，不承诺固定加速比例。现有 HTTP 客户端不需要切换。
