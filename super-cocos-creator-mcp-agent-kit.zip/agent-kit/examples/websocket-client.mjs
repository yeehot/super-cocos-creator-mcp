// Run npm ci in the repository first. Set URL/token in local environment.
import WebSocket from 'ws';
import { Client } from '@modelcontextprotocol/sdk/client/index.js';

export class WebSocketClientTransport {
  constructor(url,token){this.url=url;this.token=token;}
  async start(){
    const url=new URL(this.url);
    if(url.protocol!=='ws:'||url.hostname!=='127.0.0.1'||url.pathname!=='/mcp/ws')throw new Error('Expected local Creator WebSocket URL');
    await new Promise((resolve,reject)=>{
      this.ws=new WebSocket(url,{headers:{Authorization:`Bearer ${this.token}`},maxPayload:8*1024*1024});
      this.ws.once('open',resolve);this.ws.once('error',reject);
      this.ws.on('message',bytes=>{try{this.onmessage?.(JSON.parse(bytes.toString()));}catch(e){this.onerror?.(e);}});
      this.ws.on('error',e=>this.onerror?.(e));this.ws.on('close',()=>this.onclose?.());
    });
  }
  async send(message){await new Promise((resolve,reject)=>this.ws.send(JSON.stringify(message),e=>e?reject(e):resolve()));}
  async close(){this.ws?.terminate();}
}

if(process.argv[1]&&new URL(import.meta.url).pathname.replace(/^\//,'').endsWith(process.argv[1].replaceAll('\\','/').replace(/^\//,''))){
  const client=new Client({name:'creator-ws-example',version:'1.0'});
  try{await client.connect(new WebSocketClientTransport(process.env.CREATOR_MCP_WS_URL,process.env.CREATOR_MCP_TOKEN));console.log((await client.callTool({name:'creator_status',arguments:{}})).content);}
  catch(e){console.error(e.message);process.exitCode=1;}finally{await client.close();}
}
