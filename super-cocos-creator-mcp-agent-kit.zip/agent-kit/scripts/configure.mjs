import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

export async function generate(connection,outDirectory,nodeCommand=process.execPath){
  const input=connection.connection||connection;
  const url=new URL(input.url);
  const authorization=input.headers?.Authorization;
  if(url.protocol!=='http:'||url.hostname!=='127.0.0.1'||url.pathname!=='/mcp'||!/^Bearer \S+$/.test(authorization||''))throw new Error('Use the local Streamable HTTP connection copied from Creator');
  const name=/^[a-zA-Z0-9_-]+$/.test(input.name||'')?input.name:'super-cocos-creator-mcp';
  const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
  const target=path.resolve(outDirectory);await fs.mkdir(target,{recursive:true});
  const http={url:url.href,headers:{Authorization:authorization}};
  const stdio={command:nodeCommand,args:[path.join(root,'scripts/http-stdio.mjs')],env:{CREATOR_MCP_URL:url.href,CREATOR_MCP_TOKEN:authorization.slice(7)}};
  const files={
    'cursor.mcp.json':{mcpServers:{[name]:http}},
    'vscode.mcp.json':{servers:{[name]:{type:'http',...http}}},
    'claude-code.mcp.json':{mcpServers:{[name]:{type:'http',...http}}},
    'claude-desktop.stdio.json':{mcpServers:{[name]:stdio}},
    'generic-stdio.json':{mcpServers:{[name]:stdio}},
    'generic-http.json':{name,transport:'streamable-http',...http},
    'generic-websocket.json':{name,transport:'websocket',url:url.href.replace(/^http/,'ws')+'/ws',headers:http.headers,framing:'One MCP JSON-RPC object per UTF-8 text frame; custom adapter required'},
  };
  for(const [file,data] of Object.entries(files))await fs.writeFile(path.join(target,file),JSON.stringify(data,null,2)+'\n',{mode:0o600});
  await fs.writeFile(path.join(target,'codex.config.toml'),`[mcp_servers.${name}]\nurl = ${JSON.stringify(url.href)}\nhttp_headers = { Authorization = ${JSON.stringify(authorization)} }\n`,{mode:0o600});
  await fs.writeFile(path.join(target,'.gitignore'),'*\n');
  return {directory:target,files:[...Object.keys(files),'codex.config.toml']};
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
  const args=process.argv.slice(2),option=name=>args[args.indexOf(name)+1];
  if(!args.includes('--connection')||!args.includes('--out')){console.error('Usage: node agent-kit/scripts/configure.mjs --connection <local connection.json> --out <private directory>');process.exitCode=1;}
  else try{const result=await generate(JSON.parse(await fs.readFile(option('--connection'),'utf8')),option('--out'));console.log(`Generated ${result.files.length} client configurations in ${result.directory}. Keep private; merge only the matching server entry into your client configuration.`);}catch(e){console.error(e.message);process.exitCode=1;}
}
