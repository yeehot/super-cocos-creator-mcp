// Dependency-free stdio bridge for this plugin's stateless JSON HTTP endpoint.
import readline from 'node:readline';

const url=new URL(process.env.CREATOR_MCP_URL||'http://127.0.0.1:0/mcp');
const token=process.env.CREATOR_MCP_TOKEN;
if(url.protocol!=='http:'||url.hostname!=='127.0.0.1'||url.pathname!=='/mcp'||!token){
  console.error('Set CREATOR_MCP_URL to the local /mcp URL and CREATOR_MCP_TOKEN to the Creator token');process.exit(1);
}
let active=0;
function error(id,code,message){if(id!==undefined)process.stdout.write(JSON.stringify({jsonrpc:'2.0',id,error:{code,message}})+'\n');}
async function forward(line){
  let message;
  try{message=JSON.parse(line);}catch{error(null,-32700,'Invalid JSON');return;}
  if(!message||message.jsonrpc!=='2.0'||Array.isArray(message)){error(null,-32600,'Invalid JSON-RPC message');return;}
  if(active>=32){error(message.id,-32000,'Too many active requests');return;}
  active++;
  try{
    const response=await fetch(url,{method:'POST',redirect:'error',headers:{Authorization:`Bearer ${token}`,'Content-Type':'application/json',Accept:'application/json, text/event-stream'},body:line});
    if(!response.ok)throw new Error(`Creator HTTP ${response.status}`);
    if(response.status!==202){const text=await response.text();if(text.trim())process.stdout.write(JSON.stringify(JSON.parse(text))+'\n');}
  }catch(e){error(message.id,-32000,e.message);}
  finally{active--;if(ended&&active===0)process.exitCode=0;}
}
let ended=false;
const input=readline.createInterface({input:process.stdin,crlfDelay:Infinity});
input.on('line',line=>{if(Buffer.byteLength(line)>1024*1024){error(null,-32600,'Message too large');return;}void forward(line);});
input.on('close',()=>{ended=true;});
